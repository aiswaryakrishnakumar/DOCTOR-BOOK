<?php
session_start();
include 'connection.php';


$id1=$_GET['id'];


$query="delete from booking where id='$id1'";
$res=mysqli_query($link,$query);
echo $query;
if($row=mysqli_fetch_array($res))
{
?>

<script language="javascript">alert('cancel successfully');window.location.replace('adminbook.php');</script>

<?php
}
else
{
?>
<script language="javascript">alert('cancel successfully');window.location.replace('adminbook.php');</script>

<?php
}


?>


