<?php
include 'connection.php';
$name=$_GET['nametxt'];
$email=$_GET['emailtxt'];
$phone=$_GET['phonetxt'];
$address=$_GET['addresstxt'];
$gender=$_GET['gender'];

$location=$_GET['location'];
$password=$_GET['passtxt'];

$username=$_GET['usertxt'];

$query="insert into user(name,email,phone,address,gender,location,username,password) 
 values('$name','$email','$phone','$address','$gender','$location','$username','$password')";

$res=mysqli_query($link,$query);
if($res)
{
echo "data inserted successfully";
}
?>
