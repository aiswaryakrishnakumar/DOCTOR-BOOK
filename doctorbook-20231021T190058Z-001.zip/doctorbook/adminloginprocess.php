<?php
session_start();
include 'connection.php';
$adname=$_POST['adnametxt'];
$password=$_POST['passwordtxt'];
$query="select * from admin where adminname='$adname' and password='$password'";
$res=mysqli_query($link,$query);

if($row=mysqli_fetch_array($res))
{
$_SESSION['admin']=$adname;
header("location:adminhome.php");
}
else
{

echo "login failed";

}

?>
