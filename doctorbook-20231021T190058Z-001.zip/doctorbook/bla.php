<?php
while($row=mysqli_fetch_assoc($data1)){
 $pdf->SetFont('Times','b','14');

         $pdf->ln();
         // $pdf->Cell('30');
 $pdf->cell('50','10','                                                                        MEDICINE','5','1','c');
$pdf->cell('30','10','Medicine 1 ','1','0','c');
 $pdf->cell('30','10','Times/day','1','0','c');
 $pdf->cell('30','10','Before/after food','1','0','c');
 $pdf->cell('30','10','Medicine 2','1','0','c');
$pdf->cell('30','10','Times/day','1','0','c');
$pdf->cell('30','10','Before/after food','1','0','c');

         $pdf->cell('30','10',$row['med1'],'1','0','c');
 $pdf->cell('30','10',$row['time1'],'1','0','c');
 $pdf->cell('30','10',$row['food1'],'1','0','c');
 $pdf->cell('30','10',$row['med2'],'1','0','c');
$pdf->cell('30','10',$row['time2'],'1','0','c');
$pdf->cell('30','10',$row['food2'],'1','0','c');
?>
