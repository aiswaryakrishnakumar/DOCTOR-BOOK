<?php
include 'connection.php';
session_start();
$username=$_GET['unametxt'];


$doctorname=$_GET['drnametxt'];
$hospitalname=$_GET['hospitaltxt'];
$date=$_GET['datetxt'];
$schedule=$_GET['scheduletxt'];
$method=$_GET['methodtxt'];

if ($method=="offline")
{
$_SESSION['doctorname']=$doctorname;
$_SESSION['hospitalname']=$hospitalname;
$_SESSION['d-m-y h:i:s']=$date;
$_SESSION['schedule']=$schedule;


 header("location:offline.php");

}
else
{
header("location:book.php");

}

$query="insert into booking(username,doctorname,hospitalname,date,schedule,method) 
values('$username','$doctorname','$hospitalname','$date','$schedule','$method')";
echo $query;
$res=mysqli_query($link,$query);
if($res)
{
?>
<script language="javascript">cwindow.location.replace('book.php');</script>

<?php
}
else{

}
?>


