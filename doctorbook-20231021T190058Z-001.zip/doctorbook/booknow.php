<?php
include 'connection.php';
$uname=$_GET['unametxt'];
$doctorname=$_GET['dname'];
$day=$_GET['daytxt'];
$time=$_GET['timetxt'];
$method=$_GET['methodtxt'];		


$query="insert into booking(username,doctorname,day,time,method) 
values('$uname','$doctorname','$day','$time','$method')";
echo $query;
$res=mysqli_query($link,$query);
if($res)
{
echo "data inserted successfully";
}
?>
