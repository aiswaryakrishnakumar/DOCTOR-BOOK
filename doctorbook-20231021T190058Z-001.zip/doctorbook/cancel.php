<?php
session_start();
include 'connection.php';


$id1=$_GET['id'];
$logged=$_SESSION['logged'];

$query="delete from booking where username='$logged' and id='$id1'";
$res=mysqli_query($link,$query);
echo $query;
if($row=mysqli_fetch_array($res))
{
?>

<script language="javascript">alert('cancel successfully');window.location.replace('book.php');</script>

<?php
}
else
{
?>
<script language="javascript">alert('Cancel faild');window.location.replace('book.php');</script>

<?php
}


?>


