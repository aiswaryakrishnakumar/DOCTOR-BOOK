<?php
if($_GET)
{
include 'connection.php';

$email=$_GET['email'];
$phone=$_GET['phone'];

$query="update Doctor set phone='$phone' where email='$email'";
$res=mysqli_query($link,$query);
if($res)
{
?>
<script language="javascript">alert('updated successfully');window.location.replace('doctorlogin.html');</script>

<?php
}
else
{
?>

<script language="javascript">alert('Updation failed');window.location.replace('doctorlogin.html');</script>

<?php
}
}
?>
 

  

  

