<?php


$uid=$_GET['uid'];
$logged=$_GET['logg'];

//$t=$_GET['token'];

$pay=$_SESSION['token'];

if($uid==$logged)
{
//$_SESSION['tok']=$t;
 ?>
<script language="javascript">alert('You Can Consult');window.location.replace('video.html');</script>
<?php
}
else{
?>
<script language="javascript">alert('Can not Consult');window.location.replace('onlinedetail.php');</script>
<?php
}


?>
