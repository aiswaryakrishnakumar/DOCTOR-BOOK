<?php
session_start();
include 'connection.php';
$email=$_GET['email'];
$phone=$_GET['phone'];
$query="select * from Doctor where email='$email' and phone='$phone'";
$res=mysqli_query($link,$query);
if($row=mysqli_fetch_array($res))
{
$_SESSION['logged']=$email;
header("location:bookdr.php");
}
else
{

echo "login failed";

}

?>
