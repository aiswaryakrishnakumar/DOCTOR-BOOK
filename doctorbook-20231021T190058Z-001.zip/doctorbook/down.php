  <?php
include 'FPDF/fpdf.php';

include 'connection.php';
//database constants





$sql ="select * from booking ";
$data = mysqli_query($link,$sql);



if(isset($_POST['btn_pdf'])){
    $pdf =new FPDF('p','mm','a4');
    $pdf->SetFont('Times','b','14');
    $pdf->AddPage();
    $pdf->cell('50','10','                                    CareerLabs Online Doctor Consultation','5','1','c');
      $pdf->cell('30','10','                                                            Booking Details','5','1','c');
    // $pdf->Cell('30');
    $pdf->cell('40','10','Project Name','1','0','c');
    $pdf->cell('40','10','Team Name','1','0','c');
     $pdf->cell('40','10','Module Name','1','0','c');
     $pdf->cell('30','10','Name','1','0','c');
    $pdf->cell('40','10','Status','1','0','c');
    $pdf->SetFont('Times','','12');
    while($row=mysqli_fetch_assoc($data)){
         $pdf->ln();
         // $pdf->Cell('30');
         $pdf->cell('40','10',$row['username'],'1','0','c');
         $pdf->cell('40','10',$row['id'],'1','0','c');
 $pdf->cell('40','10',$row['id'],'1','0','c');
 $pdf->cell('40','10',$row['id'],'1','0','c');
 $pdf->cell('40','10',$row['id'],'1','0','c');
       

        
           
         
 }

    $pdf->Output();
}
?
