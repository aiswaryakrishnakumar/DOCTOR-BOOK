<?php
session_start();

$id=$_SESSION['logged'];
$token=$_SESSION['token'];
echo $token;


include 'connection.php';
$query="select * from doctor where id='$id'";
$res=mysqli_query($link,$query);
$row=mysqli_fetch_assoc($res);
$id=$row['id'];
$username=$row['username'];
$email=$row ['email'];
$phoneno=$row['phoneno'];
$gender=$row['gender'];
$address=$row['address'];
$location=$row['location'];
$doctorname=$row['doctorname'];
$specialisation=$row['specialisation'];
$date=$row['date'];
$hospital=$row['hospital'];
$day= $row['day'];
$method=$row['method'];

?>
   <h2 align="center"><u><b>VIEW YOUR DETAILS</b></u></h2>

 <table="id01">
  <pre>
  </li>
  <ul book.php ="user">
      <ul>UserName      	:</ul> <?php echo $username;?>
  <ul>Email        	: </ul> <?php echo $email;?>
  <ul>Phoneno         : </ul><?php echo $phoneno;?>
  <ul>Gender       	: </ul>
  <ul>Address     	: </ul>
  <ul>Location        : </ul>
  <ul>DoctorName      : </ul>
  <ul>Specialisation  : </ul>
   <ul>Date   	        : </ul>
  <ul>HospitalName    : </ul>
  <ul>Day          	: </ul>
   <ul>Method      	: </ul>
  
  </li>
</pre>
</table>
<br>
<br>
<br>
<script>
 view.displayObject("id01", myObject);
</script> 
<center>
<button class="btn"><i class="fa 
fa-download"></i>
<b>DOWNLOAD<b></button>
</center>

            
  
