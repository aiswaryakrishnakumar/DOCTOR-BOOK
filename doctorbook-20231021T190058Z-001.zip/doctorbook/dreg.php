<?php
include 'connection.php';
$drname=$_GET['drnametxt'];
$dremail=$_GET['emailtxt'];
$drphone=$_GET['phonetxt'];
$drgender=$_GET['gender'];
$qualification=$_GET['Qualification'];
$specialist=$_GET['specialisttxt'];
$drage=$_GET['agetxt'];
$drschedule=$_GET['scheduletxt'];
$workinghos=$_GET['hospitaltxt'];
$day=$_GET['daystxt'];		
$consultationfee=$_GET['consultationtxt'];

$query="insert into Doctor(doctorname,email,phone,gender,qualification,specialist,age,schedule,workinghos,days,consultationfee) 
values('$drname','$dremail','$drphone','$drgender','$qualification','$specialist','$drage','$drschedule','$workinghos','$day','$consultationfee')";
//echo $query;
$res=mysqli_query($link,$query);
if($res)
{
?>
<script language="javascript">alert('Add successfully');window.location.replace('Adregister.html');</script>

<?php
}
else
{
/*?>

<script language="javascript">alert('Add failed');window.location.replace('dreg.php');</script>

<?php*/
}

?>


