<?php
include 'connection.php';
$name=$_GET['nametxt'];
$email=$_GET['emailtxt'];
$usability=$_GET['usability'];
$suggestion=$_GET['writetxt'];

$query="insert into feedback (name,email,usability,suggestion) 
values('$name','$email','$usability','$suggestion')";
echo "$query";
$res=mysqli_query($link,$query);
if($res)
{
header("location:home.php");
}

?>

