<?php
if($_GET)
{
include 'connection.php';

$username=$_GET['mailtxt'];
$Newpassword=$_GET['passwtxt'];

$query="update register set password='$Newpassword',ConfirmPassword='$Newpassword' where email='$username'";
$res=mysqli_query($link,$query);
if($res)


{
?>
<script language="javascript">alert('updated successfully');window.location.replace('adlogin.html');</script>

<?php
}
else
{
?>

<script language="javascript">alert('Updation failed');window.location.replace('adlogin.html');</script>

<?php
}
}
?>
 

  

  

