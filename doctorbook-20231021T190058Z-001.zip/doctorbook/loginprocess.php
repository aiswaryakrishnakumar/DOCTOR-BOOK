<?php
session_start();
include 'connection.php';
$username=$_GET['unametxt'];
$password=$_GET['passwtxt'];
$query="select * from register where username='$username' and password='$password'";
$res=mysqli_query($link,$query);

if($row=mysqli_fetch_array($res))
{$_SESSION['uid']=$row['id'];
$_SESSION['logged']=$username;
header("location:home.php");
}
else
{

echo "login failed";

}

?>
