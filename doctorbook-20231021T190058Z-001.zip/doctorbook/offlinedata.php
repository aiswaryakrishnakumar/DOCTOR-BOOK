<?php
include 'connection.php';
session_start();
$username=$_GET['usertxt'];
$doctorname=$_GET['drnametxt'];
$hospitalname=$_GET['hospitaltxt'];
$date=$_GET['datetxt'];
$schedule=$_GET['scheduletxt'];
$Streetno=$_GET['streettxt'];
$Landmark=$_GET['lantxt'];
$Postoffice=$_GET['posttxt'];
$Pincode=$_GET['pintxt'];
$Address=$_GET['addresstxt'];
$District=$_GET['location'];
$Travelfee=$_GET['traveltxt'];

$d=$_SESSION['doctorname'];
$h=$_SESSION['hospitalname'];
$date=$_SESSION['d-m-y h:i:s'];
$sch=$_SESSION['schedule'];


$query="insert into offline (username,doctorname,hospitalname,date,schedule,Streetno,Landmark,Postoffice,pincode,Adress,District,Travelfee) 
values('$username','$d','$h','$date','$sch','$Streetno','$Landmark','$Postoffice','$Pincode','$Address','$District','$Travelfee')";
echo "$query";
$res=mysqli_query($link,$query);
if($res)
{
?>
<script language="javascript">alert('Add successfully');window.location.replace('book.php');</script>

<?php
}
else
{
?>

<script language="javascript">alert('Add failed');window.location.replace('book.php');</script>

<?php
}
?>


