<?php


$uid=$_GET['uid'];
$logged=$_GET['logged'];

//$t=$_GET['token'];

$pay=$_SESSION['token'];

if($uid==$logged)
{
//$_SESSION['tok']=$t;
 ?>
<script language="javascript">alert('YOU CAN PAY ');window.location.replace('payment.php');</script>
<?php
}
else{
?>
<script language="javascript">alert('YOU CANOT PAY');window.location.replace('offlinedetails.php');</script>
<?php
}


?>
