<?php
include 'FPDF/fpdf.php';

include 'connection.php';
//database constants

//$token=$_SESSION['token1'];
//echo $token;
$id=$_GET['id'];
$sql ="select * from booking where id='$id' ";
$data = mysqli_query($link,$sql);
$id=$_GET['id'];
$sql ="select * from prescribe where id='$id' ";
$data1 = mysqli_query($link,$sql);

    $pdf =new FPDF('p','mm','a4');
    $pdf->SetFont('Times','b','14');
    $pdf->AddPage();
    $pdf->cell('50','10','                                    CareerLabs Online Doctor Consultation','5','1','c');
      $pdf->cell('30','10','                                                            Booking Details','5','1','c');
    // $pdf->Cell('30');
  $pdf->cell('30','10','Name','1','0','c');
 $pdf->cell('30','10','Doctor','1','0','c');
 $pdf->cell('30','10','Hospital','1','0','c');
 $pdf->cell('30','10','date','1','0','c');
$pdf->cell('30','10','schedule','1','0','c');
$pdf->cell('30','10','method','1','0','c');
   
    $pdf->SetFont('Times','','12');
    while($row=mysqli_fetch_assoc($data)){
         $pdf->ln();
         // $pdf->Cell('30');
         $pdf->cell('30','10',$row['username'],'1','0','c');
 $pdf->cell('30','10',$row['doctorname'],'1','0','c');
 $pdf->cell('30','10',$row['hospitalname'],'1','0','c');
 $pdf->cell('30','10',$row['date'],'1','0','c');
$pdf->cell('30','10',$row['schedule'],'1','0','c');
$pdf->cell('30','10',$row['method'],'1','0','c');
  
 }

$pdf->cell('50','10',' ','5','1','c');
$pdf->cell('30','10','Medicine 1 ','1','0','c');
 $pdf->cell('30','10','Times/day','1','0','c');
 $pdf->cell('30','10','B/a food','1','0','c');
 $pdf->cell('30','10','Medicine 2','1','0','c');
$pdf->cell('30','10','Times/day','1','0','c');
$pdf->cell('30','10','B/a food','1','0','c');
while($row=mysqli_fetch_assoc($data1)){
         $pdf->ln();
         // $pdf->Cell('30');
                                                                        
         $pdf->cell('30','10',$row['med1'],'1','0','c');
 $pdf->cell('30','10',$row['time1'],'1','0','c');
 $pdf->cell('30','10',$row['food1'],'1','0','c');
 $pdf->cell('30','10',$row['med2'],'1','0','c');
$pdf->cell('30','10',$row['time2'],'1','0','c');
$pdf->cell('30','10',$row['food2'],'1','0','c');

 }


    $pdf->Output();

?>
