<?php
include 'connection.php';
$uid=$_SESSION['id'];
$logged=$_GET['logged'];


echo $logged;
//$t=$_GET['token'];

//$pay=$_SESSION['token'];

if($uid==$logged)
$med1=$_GET['med'];
$time1=$_GET['time'];
$food1=$_GET['food'];
$med2=$_GET['medicine'];
$time2=$_GET['times'];
$food2=$_GET['bafood'];

$query="insert into prescribe(med1,time1,food1,med2,time2,food2)  values('$med1','$time1','$food1','$med2','$time2','$food2')";
echo $query;

$res=mysqli_query($link,$query);

if($res)

{
//<script language="javascript">alert('Add successfully');window.location.replace('home.php');
//</script>


header("location:onlinedetaildr.php");
echo "data inserted successfully";
}
?>

