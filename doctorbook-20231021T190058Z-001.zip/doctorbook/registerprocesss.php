<?php
include 'connection.php';
echo "Hai";
$name=$_GET['nametxt'];
$email=$_GET['emailtxt'];
$phone=$_GET['phonetxt'];
$address=$_GET['addresstxt'];
$gender=$_GET['gender'];
$location=$_GET['location'];
$UserName=$_GET['usertxt'];
$password=$_GET['passtxt'];

echo $name;
echo $email;
echo $phone;
echo $address;
echo $gender;
echo $location;
echo $UserName;
echo $password;
echo $ConfirmPassword;


$query="insert into register(name,email,phone,gender,address,location,username,password)  values('$name','$email','$phone','$gender','$address','$location','$UserName','$password')";
echo $query;

$res=mysqli_query($link,$query);

if($res)

{
//<script language="javascript">alert('Add successfully');window.location.replace('home.php');
//</script>


header("location:adlogin.html");
echo "data inserted successfully";
}
?>

