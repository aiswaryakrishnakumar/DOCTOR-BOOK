<?php
include 'connection.php';
$drname=$_GET['name'];
$query="delete from Doctor where doctorname='$drname'";
$res=mysqli_query($link,$query);
if($res)
{
?>
<script language="javascript">alert('deleted successfully');window.location.replace('doctorslist.php');</script>

<?php
}
else
{
?>
<script language="javascript">alert('deletion failed');window.location.replace('doctorslist.php');</script>

<?php
}

?>


