<?php
    if($_POST)
	{
		session_start();
        include('connection.php');
        $psw = $_POST["password"];
		$em=$_POST["emailid"];
        $token = $_SESSION['token'];
        //$Email = $_SESSION['email'];
		 //echo $Email;
        //$hash = password_hash( $psw , PASSWORD_DEFAULT );
		
      $sql = mysqli_query($link,"SELECT * FROM register WHERE email='$em'");
        //$query = mysqli_num_rows($sql);
  	   // $fetch = mysqli_fetch_assoc($sql);
		if($sql)
	{
            //$new_pass = $hash;
	mysqli_query($link,"UPDATE register SET password='$psw' WHERE email='$em'");
						$_SESSION['logged']=$em;
						$q="select name from register where email='$em'";	
						$res=mysqli_query($link,$q);
						while($row=mysqli_fetch_array($res))
							{
								$user=$row['name'];				
								//echo $user;
								$_SESSION['username']=$user;
							} 

						?>				
			
            <script>        
                alert("<?php echo "your password has been successful reset"?>");
				 window.location.replace("home.php");
            </script>
            <?php
				
        }
			else
			{
            ?>
						<script>
						    alert("<?php echo "Please_try_again"?>");
						</script>
            <?php
        }
    }

?>
