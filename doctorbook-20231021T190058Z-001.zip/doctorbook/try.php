<a href="uploads/aishu/Screenshot from 2022-06-16 15-52-09.png">
  <img src="uploads/aishu/Screenshot from 2022-06-16 15-52-09.png" alt="An image">
</a>
