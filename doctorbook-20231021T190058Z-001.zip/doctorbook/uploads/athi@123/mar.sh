echo "student"
echo "enter the number of student"
read n
echo "enter the mark of 15 students"
for ((i=0;i<n;i++))
do
read A[i]
done
echo "array elements are:"
for((i=0;i<n;i++))
do
echo $ [ A[i] ]
done
sum=0
for((i=0;i<n;i++))
do
sum=` expr $ sum +
