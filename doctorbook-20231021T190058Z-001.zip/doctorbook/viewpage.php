<?php
include 'connection.php';
$name=$_GET['name'];
$age=$_GET['age'];
$email=$_GET['email'];
$phone=$_GET['phone'];
gender=$_GET['gender'];
$address=$_GET['address'];
$location=$_GET['location'];
$drname=$_GET['doctorname'];
$specialist=$_GET['specialization'];
$time=$_GET['time'];
$workinghos=$_GET['hospitalname'];
$day=$_GET['day'];	
$method=$_GET['method'];	
$payment=$_GET['payment'];		


$query="insert into view(name,email,age,phone,gender,address,location,doctorname,specialization,time,hospitalname,day,method,payment) 
values('$name','$age','$email','$phone','$gender','$address','$location','$drname',$specialist',,'$time','$workinghos','$day','$method','$payment',)";
echo $query;
$res=mysqli_query($link,$query);
if($res)
{
echo "data inserted successfully";
}
?>
